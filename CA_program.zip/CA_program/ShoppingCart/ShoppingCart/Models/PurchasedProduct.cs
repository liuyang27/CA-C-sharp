﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShoppingCart.Models
{
    public class PurchasedProduct
    {
        public int CustomerID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
        public string ImageSrc { get; set; }
        public string ProductName { get; set; }
        public string ProductDescription { get; set; }
        public List<string> ActivationCodes { get; set; }
        public DateTime PurchasedDate { get; set; }
    }
}