﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShoppingCart.DB;

namespace ShoppingCart.Controllers
{
    public class DataBaseController : Controller
    {

        public ActionResult UpdateQuantity(int CustomerId, int quantity, int productId)
        {
            ProductData.UpdateQuantity(CustomerId, quantity, productId);
            return Json("ok");
        }


        public ActionResult AddProduct (int CustomerId,int productId)
        {
            ProductData.AddProduct(CustomerId, productId); ;
            return Json("ok");
        }

        public ActionResult RemoveProduct(int CustomerId, int productId)
        {
            ProductData.RemoveProduct(CustomerId, productId); ;
            return Json("ok");
        }


    }
}