﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShoppingCart.Models;
using ShoppingCart.Common;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using ShoppingCart.DB;
using ShoppingCart.Filter;

namespace ShoppingCart.Controllers
{
    [UserAuthorizer]
    public class HomeController : Controller
    {

        public ActionResult Index(string sessionid, string searchItem)
        {
            UserInfo user = SessionData.GetUserBySessionId(sessionid);

            List<CartProduct> GalleryProducts = null;
            if (searchItem == null || searchItem=="")
                GalleryProducts = ProductData.GetAll();
            else
                GalleryProducts = SearchData.GetItems(searchItem);

            int numberInCart = ProductData.GetNumberInCart(user.ID);
            ViewData["numberInCart"] = numberInCart;
            ViewData["user"] = user;
            ViewData["searchItem"] = searchItem;
            ViewData["sessionid"] = sessionid;
            return View(GalleryProducts);
        }
       

        public ActionResult ShoppingCart(string sessionid)
        {
            UserInfo user = SessionData.GetUserBySessionId(sessionid);
            List<CartProduct> CartProducts = ProductData.GetCartProducts(user.ID);
            ViewBag.userinfo = user;
            ViewData["sessionid"] = sessionid;
            return View(CartProducts);
        }


        public ActionResult Checkout(string sessionid)
        {
            UserInfo user = SessionData.GetUserBySessionId(sessionid);
            string constr = ConfigurationManager.ConnectionStrings["SQLServer"].ConnectionString;
            using(SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("spCheckout", con))
                {
                    
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@CustomerID", user.ID));
                        
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            ViewData["sessionid"] = sessionid;
            return RedirectToAction("PurchaseView",new { sessionid= sessionid });
        }
            

        public ActionResult PurchaseView(string sessionid)
        {
            UserInfo user = SessionData.GetUserBySessionId(sessionid);

            List<PurchasedProduct> PurchasedProducts = new List<PurchasedProduct>();

            PurchasedProducts = ProductData.GetPurchasedProducts(user.ID);

            ViewData["sessionid"] = sessionid;
            return View(PurchasedProducts);
        }

        public ActionResult RemoveProduct(string sessionid,int productid)
        {
            UserInfo user = SessionData.GetUserBySessionId(sessionid);
            ProductData.RemoveProduct(user.ID, productid);
            return RedirectToAction("ShoppingCart","Home",new { sessionid = sessionid });
        }

    }
}