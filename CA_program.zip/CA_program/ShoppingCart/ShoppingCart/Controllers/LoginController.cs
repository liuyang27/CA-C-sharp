﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShoppingCart.Common;
using ShoppingCart.Models;
using ShoppingCart.DB;

namespace ShoppingCart.Controllers
{
    public class LoginController : Controller
    {
        [HttpGet]
        [ActionName("Login")]
        public ActionResult Login_Get()
        {
            return View();
        }

        [HttpPost]
        [ActionName("Login")]
        public ActionResult Login_Post(Login login)
        {
            Login DBLogin = null;

            SqlDataReader reader = SQLHelper.ExecuteDataReader("select * from Customer where UserName=@username",
                new SqlParameter("@username", login.UserName));

            while (reader.Read())
            {
                DBLogin = new Login()
                {
                    UserName = (string)reader["UserName"],
                    Password = (string)reader["Password"]
                };
            }

            if (DBLogin == null)
                return View("Login");

            login.Password = MD5.GET(login.Password);
            if (DBLogin.Password != (string)login.Password)
                return View("Login");

            string sessionid = SessionData.CreateSession(login.UserName);
            //Session["sessionid"] = sessionid;
            return RedirectToAction("Index", "Home",new{ sessionid= sessionid });

        }
    }
}