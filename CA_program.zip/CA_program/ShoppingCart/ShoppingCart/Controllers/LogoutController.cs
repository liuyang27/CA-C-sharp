﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShoppingCart.Filter;
using ShoppingCart.DB;

namespace ShoppingCart.Controllers
{
    [UserAuthorizer]
    public class LogoutController : Controller
    {
        public ActionResult Logout(string sessionid)
        {
            SessionData.RemoveSession(sessionid);

            return RedirectToAction("Login", "Login");
        }
    }
}