﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using ShoppingCart.Common;
using ShoppingCart.Models;

namespace ShoppingCart.DB
{
    public class ProductData
    {
        public static List<CartProduct> GetAll()
        {
            List<CartProduct> GalleryProducts = new List<CartProduct>();
            SqlDataReader reader = SQLHelper.ExecuteDataReader(@"select ID,ProductName,ProductDescription,UnitPrice,ImageSource from Product");
            while (reader.Read())
            {
                CartProduct product = new CartProduct()
                {
                    ProductID = (int)reader["ID"],
                    UnitPrice = (decimal)reader["UnitPrice"],
                    ProductName = (string)reader["ProductName"],
                    ProductDescription = (string)reader["ProductDescription"],
                    ImageSrc = reader["ImageSource"].GetType().Equals(DBNull.Value) ? "" : reader["ImageSource"].ToString()
                };
                GalleryProducts.Add(product);
            }
            return GalleryProducts;
        }


        public static void UpdateQuantity(int CustomerId,int quantity,int productId)
        {
             SQLHelper.ExecuteNonQuery(@"update cart set Quantity=@Quantity where ProductID=@ProductID and CustomerID=@CustomerID",
                                    new SqlParameter("@Quantity",quantity),
                                    new SqlParameter("@ProductID", productId),
                                    new SqlParameter("@CustomerID", CustomerId));  
        }


        public static void AddProduct(int CustomerId, int productId)
        {
            object o = SQLHelper.ExecuteScalar("select * from Cart where CustomerID = @CustomerID and ProductID = @productId",
                                    new SqlParameter("@ProductID", productId),
                                    new SqlParameter("@CustomerID", CustomerId));

            if (o == null || o is DBNull)
            {
                decimal unitprice = (decimal)SQLHelper.ExecuteScalar("select UnitPrice from product where id = @id",
                                    new SqlParameter("@id", productId));
     
                SQLHelper.ExecuteNonQuery(@"insert into Cart values(@CustomerID,@ProductID,@UnitPrice,1)",
                                           new SqlParameter("@CustomerID", CustomerId),
                                           new SqlParameter("@ProductID", productId),
                                           new SqlParameter("@UnitPrice", unitprice));
            }
            else
            {
                string constr = ConfigurationManager.ConnectionStrings["SQLServer"].ConnectionString;
                using (SqlConnection con = new SqlConnection(constr))
                {
                    using (SqlCommand cmd = new SqlCommand("spAddProduct", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@CustomerID", CustomerId));
                        cmd.Parameters.Add(new SqlParameter("@ProductID", productId));   
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
            }
  
        }


        public static int GetNumberInCart(int CustomerId)
        {
            object o = SQLHelper.ExecuteScalar(@"select sum(quantity) from Cart where CustomerID=@CustomerID", new SqlParameter("@CustomerID", CustomerId));
            if (o == null || o is DBNull)
                return 0;
            else
                return (int)o;
        }


        public static List<PurchasedProduct> GetPurchasedProducts(int CustomerId)
        {
            List<tempData> tempDats = new List<tempData>();

            SqlDataReader reader = SQLHelper.ExecuteDataReader(@"select ProductID, count(ProductID) as Quantity,PurchaseDate from Purchased 
                                            where CustomerID = @CustomerID group by ProductID,PurchaseDate order by PurchaseDate desc",
                                            new SqlParameter("@CustomerID", CustomerId));
            while (reader.Read())
            {
                tempData tempData = new tempData()
                {

                    ProductID = (int)reader["ProductID"],
                    Quantity = (int)reader["Quantity"],
                    PurchasedDate = (DateTime)reader["PurchaseDate"],
                };
                tempDats.Add(tempData);
            }

            List<PurchasedProduct> PurchasedProducts = new List<PurchasedProduct>();
            foreach (tempData order in tempDats)
            {
                List<string> codeList = new List<string>();
                PurchasedProduct purchasedProduct = new PurchasedProduct();

                SqlDataReader reader1 = SQLHelper.ExecuteDataReader(@"select ActivationCode from Purchased where CustomerID=@CustomerID and ProductID=@ProductID and PurchaseDate=@PurchaseDate",
                                            new SqlParameter("@CustomerID", CustomerId),
                                            new SqlParameter("@ProductID", order.ProductID),
                                            new SqlParameter("@PurchaseDate", order.PurchasedDate));
                while (reader1.Read())
                {
                    string code = (string)reader1["ActivationCode"];
                    codeList.Add(code);
                }


                SqlDataReader reader2 = SQLHelper.ExecuteDataReader(@"select ProductName,ProductDescription,ImageSource from Product where ID=@ID",
                                           new SqlParameter("@ID", order.ProductID));
                while (reader2.Read())
                {
                    purchasedProduct.CustomerID = CustomerId;
                    purchasedProduct.ProductID = order.ProductID;
                    purchasedProduct.Quantity = order.Quantity;
                    purchasedProduct.PurchasedDate = order.PurchasedDate;
                    purchasedProduct.ProductName = (string)reader2["ProductName"];
                    purchasedProduct.ProductDescription = (string)reader2["ProductDescription"];
                    purchasedProduct.ImageSrc = reader2["ImageSource"].GetType().Equals(DBNull.Value) ? "" : reader2["ImageSource"].ToString();
                    purchasedProduct.ActivationCodes = codeList;
                    PurchasedProducts.Add(purchasedProduct);
                }

            }
            return PurchasedProducts;
        }

        class tempData
        {
            public int ProductID { get; set; }
            public int Quantity { get; set; }
            public DateTime PurchasedDate { get; set; }
        }


        public static List<CartProduct> GetCartProducts(int CustomerId)
        {
            List<CartProduct> CartProducts = new List<CartProduct>();
            SqlDataReader reader = SQLHelper.ExecuteDataReader(@"select Cart.CustomerID, Cart.ProductID as ProductID,Cart.UnitPrice as UnitPrice,Cart.Quantity as Quantity,
                                                               Product.ImageSource as ImageSource,Product.ProductName as ProductName,Product.ProductDescription as ProductDescription
                                                               from Cart,Product 
                                                               where Cart.CustomerID = @customerid and Cart.ProductID = Product.ID",
                                                               new SqlParameter("@customerid", CustomerId));

            while (reader.Read())
            {
                CartProduct product = new CartProduct()
                {
                    CustomerID = CustomerId,
                    ProductID = (int)reader["ProductID"],
                    UnitPrice = (decimal)reader["UnitPrice"],
                    Quantity = (int)reader["Quantity"],
                    ProductName = (string)reader["ProductName"],
                    ProductDescription = (string)reader["ProductDescription"],
                    ImageSrc = reader["ImageSource"].GetType().Equals(DBNull.Value) ? "" : reader["ImageSource"].ToString()
                };
                CartProducts.Add(product);
            }
            return CartProducts;
        }


        public static void RemoveProduct(int CustomerId, int productId)
        {
            SQLHelper.ExecuteNonQuery(@"delete from Cart where CustomerID=@CustomerID and ProductID=@ProductID",
                                    new SqlParameter("@CustomerID", CustomerId),
                                    new SqlParameter("@ProductID", productId));
        }

    }
}