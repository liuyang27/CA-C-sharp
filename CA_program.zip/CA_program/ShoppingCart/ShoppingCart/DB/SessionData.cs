﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using ShoppingCart.Models;
using ShoppingCart.Common;

namespace ShoppingCart.DB
{
    public class SessionData
    {
        static string constr = ConfigurationManager.ConnectionStrings["SQLServer"].ConnectionString;

        public static bool IsActiveSessionId(string sessionId)
        {

            using (SqlConnection conn = new SqlConnection(constr))
            {
                conn.Open();
                string sql = @"SELECT COUNT(*) FROM Customer
                    WHERE SessionID = '" + sessionId + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                int count = (int)cmd.ExecuteScalar();
                return (count == 1);
            }
        }

        public static string CreateSession(string username)
        {
            string sessionId = Guid.NewGuid().ToString();

            SQLHelper.ExecuteNonQuery("update Customer set SessionID=@SessionID where UserName=@UserName",
                new SqlParameter("@SessionID", sessionId),
                new SqlParameter("@UserName", username));
            return sessionId;
        }

        public static void RemoveSession(string sessionId)
        {
            using (SqlConnection conn = new SqlConnection(constr))
            {
                conn.Open();
                string sql = @"UPDATE Customer SET SessionID = NULL 
                    WHERE SessionId = '" + sessionId + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
            }
        }

        public static UserInfo GetUserBySessionId(string sessionId)
        {
            UserInfo user = null;

            using (SqlConnection conn = new SqlConnection(constr))
            {
                conn.Open();

                string q = @"SELECT ID,CustomerName,SessionID FROM Customer where SessionID = '" + sessionId + "'";

                SqlCommand cmd = new SqlCommand(q, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    user = new UserInfo()
                    {
                        ID = (int)reader["ID"],
                        CustomerName = (string)reader["CustomerName"],
                        SessionID = (string)reader["SessionID"]
                    };
                }
            }

            return user;
        }
    }
}
