﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using ShoppingCart.Common;
using ShoppingCart.Models;

namespace ShoppingCart.DB
{
    public class SearchData
    {
        public static List<CartProduct> GetItems(string keyword)
        {
            List<CartProduct> SearchProducts = new List<CartProduct>();
            SqlDataReader reader = SQLHelper.ExecuteDataReader(@"select * from Product where ProductName like '%" + keyword + "%' or ProductDescription like '%" + keyword + "%'");

            while (reader.Read())
            {
                CartProduct product = new CartProduct()
                {
                    ProductID = (int)reader["ID"],
                    UnitPrice = (decimal)reader["UnitPrice"],
                    ProductName = (string)reader["ProductName"],
                    ProductDescription = (string)reader["ProductDescription"],
                    ImageSrc = reader["ImageSource"].GetType().Equals(DBNull.Value) ? "" : reader["ImageSource"].ToString()
                };
                SearchProducts.Add(product);
            }
            return SearchProducts;
        }
    }
}